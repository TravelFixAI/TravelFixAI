# TravelFix AI Android

A native Android WebView wrapper around the TravelFix AI prototype. The app includes flight, baggage, hotel, food, translation, documents, transport, payment, voice input, emergency mode, trip wallet placeholder, and travel-help flows.

## Build
Open this folder in Android Studio and build `app`.

Or push it to GitHub and run the included **Build TravelFix AI APK** workflow. The APK will appear as a workflow artifact.
